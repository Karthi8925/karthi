const apiKey = "YOUR_API_KEY"; // Replace with your OpenWeatherMap API key

function getWeather() {
  const city = document.getElementById("city").value;
  if (city === "") {
    alert("Please enter a city name.");
    return;
  }

  const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

  fetch(weatherUrl)
    .then(response => response.json())
    .then(data => {
      if (data.cod === "404") {
        document.getElementById("weather-result").innerHTML = "City not found!";
        return;
      }

      const lat = data.coord.lat;
      const lon = data.coord.lon;

      document.getElementById("weather-result").innerHTML = `
        <h3>${data.name}, ${data.sys.country}</h3>
        <p>Temperature: ${data.main.temp}°C</p>
        <p>Humidity: ${data.main.humidity}%</p>
        <p>Weather: ${data.weather[0].description}</p>
      `;

      getAirQuality(lat, lon);
      getEarthquakes(lat, lon);
    })
    .catch(error => console.error("Error fetching weather data:", error));
}

function getAirQuality(lat, lon) {
  const airQualityUrl = `https://api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=${apiKey}`;

  fetch(airQualityUrl)
    .then(response => response.json())
    .then(data => {
      const air = data.list[0].components;
      document.getElementById("air-quality-result").innerHTML = `
        <p>PM2.5: ${air.pm2_5} µg/m³</p>
        <p>CO: ${air.co} µg/m³</p>
        <p>NO2: ${air.no2} µg/m³</p>
        <p>O3: ${air.o3} µg/m³</p>
      `;
    })
    .catch(error => console.error("Error fetching air quality data:", error));
}

function getEarthquakes(lat, lon) {
  const earthquakeUrl = `https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&latitude=${lat}&longitude=${lon}&maxradiuskm=500&limit=1`;

  fetch(earthquakeUrl)
    .then(response => response.json())
    .then(data => {
      if (data.features.length === 0) {
        document.getElementById("earthquake-result").innerHTML = `<p>No recent earthquakes near this location.</p>`;
        return;
      }

      const quake = data.features[0].properties;
      document.getElementById("earthquake-result").innerHTML = `
        <p>Magnitude: ${quake.mag}</p>
        <p>Location: ${quake.place}</p>
        <p>Time: ${new Date(quake.time).toLocaleString()}</p>
      `;
    })
    .catch(error => console.error("Error fetching earthquake data:", error));
}
